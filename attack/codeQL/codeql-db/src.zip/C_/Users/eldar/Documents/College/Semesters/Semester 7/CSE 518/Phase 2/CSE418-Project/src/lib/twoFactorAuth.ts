/**
 * Client-side 2FA functions that call server-side APIs
 * This keeps sensitive operations (code generation, email sending) on the server
 */

/**
 * Request the server to generate and send a verification code
 */
export async function sendVerificationCode(userId: string, email: string): Promise<void> {
	const response = await fetch("/api/2fa/send-code", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({ userId, email }),
	});

	if (!response.ok) {
		const error = await response.json();
		throw new Error(error.error || "Failed to send verification code");
	}

	const data = await response.json();
	console.log(data.message);
}

/**
 * Verify the code entered by the user
 */
export async function verifyCode(userId: string, code: string): Promise<{ valid: boolean; customToken?: string }> {
	const response = await fetch("/api/2fa/verify-code", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({ userId, code }),
	});

	const data = await response.json();

	if (!response.ok) {
		console.error(data.error);
		return { valid: false };
	}

	return { valid: data.valid, customToken: data.customToken };
}
